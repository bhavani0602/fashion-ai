# Backend - FastAPI for AI Processing
from fastapi import FastAPI, File, UploadFile, HTTPException
import uvicorn
from PIL import Image
import io

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Fashion AI Backend is Running"}

@app.post("/upload")
async def upload_image(file: UploadFile = File(...)):
    try:
        image = Image.open(io.BytesIO(await file.read()))
        # TODO: Process image for body measurements & type
        return {"message": "Image received and processed"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
